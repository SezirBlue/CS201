#ifndef NAMESORT
#define NAMESORT

#include <string>
#include<vector>

void nameSort(std::vector<std::pair<std::string, std::string>> & vec);

#endif // !
